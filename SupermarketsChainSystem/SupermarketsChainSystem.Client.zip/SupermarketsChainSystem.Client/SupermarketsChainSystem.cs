﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SupermarketsChainSystem.Client
{
    public class SupermarketsChainSystem
    {
        public static ExcelManager ExcelManager = new ExcelManager();
        public static ZipManager zm = new ZipManager();
        public static List<StoreReport> SupermarketsReports = new List<StoreReport>();

        public static void Main()
        {
            SystemManager.DropFolder(SystemManager.tempDir);
            foreach (string file in Directory.EnumerateFiles(SystemManager.reportsDir, "*.*", SearchOption.AllDirectories))
            {
                zm.UnZipFile(file, SystemManager.tempDir);
                foreach (string excelFile in Directory.EnumerateFiles(SystemManager.tempDir, "*.*", SearchOption.AllDirectories))
                {
                    StoreReport storeReport = ExcelManager.GetData(excelFile);
                    SupermarketsReports.Add(storeReport);
                }
                SystemManager.DropFolder(SystemManager.tempDir);
            }
            foreach (var report in SupermarketsReports)
            {
                Console.WriteLine("Store name: " + report.StoreName);
                foreach (var product in report.productReports)
                {
                    Console.WriteLine(string.Format("Product name: {0}, Quantity: {1}, Unit price: {2}, Sum: {3} ",product.ProductName,product.Quantity,product.UnitPrice,product.Sum));
                }
                Console.WriteLine("Total: "+report.TotalSum);
                Console.WriteLine("------------------------------------------");
            }
        }
    }
}
